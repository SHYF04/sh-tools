#include <stdio.h>
#include <inttypes.h>
#include "esp_attr.h"
#include "driver/gptimer.h"
#include "../components/sh_event/include/sh_event.h"
#include "freertos/idf_additions.h"

sh_event_handle_t handle1, handle2, handle3, handle4;

void test1(sh_event_handle_t handle, void* param, sh_event_size_t len)
{
    printf("test1\n");
    sh_event_clear(handle1);
}

void test2(sh_event_handle_t handle, void* param, sh_event_size_t len)
{
    printf("test2\n");
    sh_event_clear(handle2);
}

void test3(sh_event_handle_t handle, void* param, sh_event_size_t len)
{
    printf("test3\n");
    sh_event_clear(handle3);
}

void test4(sh_event_handle_t handle, void* param, sh_event_size_t len)
{
    printf("test4\n");
    sh_event_unregister(&handle2);
    sh_event_set(handle1);
    sh_event_set(handle2);
    sh_event_set(handle3);
}

static bool IRAM_ATTR sh_event_cb (gptimer_handle_t timer, const gptimer_alarm_event_data_t *edata, void *user_data)
{
    (void) timer;
    (void) edata;
    (void) user_data;
    sh_event_tick_inc(1);
    return true;
}

void app_main(void)
{
    sh_event_init();
    sh_event_register(&handle1, 1, test1, NULL, 0);
    sh_event_register(&handle2, 3, test2, NULL, 0);
    sh_event_register(&handle3, 0, test3, NULL, 0);
    sh_event_timer_register(&handle4, 0, 1000, test4, NULL, 0);

    sh_event_set(handle1);
    sh_event_set(handle2);
    sh_event_set(handle3);

    gptimer_handle_t gptimer = NULL;
    gptimer_config_t event_timer = 
    {
        .clk_src = GPTIMER_CLK_SRC_DEFAULT,
        .direction = GPTIMER_COUNT_UP,
        .resolution_hz = 1 * 1000 * 1000, // 1MHz, 1 tick = 1us
    };
    ESP_ERROR_CHECK(gptimer_new_timer(&event_timer, &gptimer));

    gptimer_event_callbacks_t event_timer_cb = 
    {
        .on_alarm = sh_event_cb,
    };
    ESP_ERROR_CHECK(gptimer_register_event_callbacks(gptimer, &event_timer_cb, NULL));
    ESP_ERROR_CHECK(gptimer_enable(gptimer));

    gptimer_alarm_config_t alarm_config = 
    {
        .reload_count = 0,
        .alarm_count = 1000, // period = 1ms
        .flags.auto_reload_on_alarm = true,
    };
    ESP_ERROR_CHECK(gptimer_set_alarm_action(gptimer, &alarm_config));
    ESP_ERROR_CHECK(gptimer_start(gptimer));

    while(1)
    {
        sh_event_scheduler();

        vTaskDelay(pdMS_TO_TICKS(10)); // 让出CPU，给IDLE运行喂狗
    }
}
